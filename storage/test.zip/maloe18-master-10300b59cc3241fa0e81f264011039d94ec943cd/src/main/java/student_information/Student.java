package student_information;

import java.util.TreeSet;

public class Student implements Comparable<Student>{
    String name;
    int age;
    String department;
    String result;
    double marks;

   @Override
    public String toString() {
        return String.format("%s \t \t %d \t \t %s \t \t %s \t \t %.2f\n",getName(),getAge(),getDepartment(), getResult(), getMarks());
    }

    public Student(String name, int age, String department, String result, double marks){
       this.name = name;
       this.age = age;
       this.department = department;
       this.result = result;
       this.marks = marks;
    }

    public String getName(){return this.name;}
    public int getAge(){return this.age;}
    public String getDepartment(){return this.department;}
    public String getResult(){return this.result;}
    public double getMarks(){return this.marks;}

    @Override
    public int compareTo(Student s) {
       return Double.compare(this.marks, s.marks);
    }

    public static void main(String[] args) {

       TreeSet<Student> studentSet1 = new TreeSet<>();

       Student student1 = new Student("Tim", 20, "me","pass",9.80);
       Student student2 = new Student("Ella", 19, "ece","fail",3.20);
       Student student3 = new Student("Bo", 21, "me","pass",9.20);
       Student student4 = new Student("Emma", 19, "ece","pass",9.60);
       Student student5 = new Student("Paul", 20, "cse","pass",8.60);
       studentSet1.add(student1);
       studentSet1.add(student2);
       studentSet1.add(student3);
       studentSet1.add(student4);
       studentSet1.add(student5);

//        Task 1a
        System.out.println("Sorting based on Marks");
        System.out.println(studentSet1);

//        Task 1b
        TreeSet<Student> studentSet2 = new TreeSet<>(new AgeComparator());
        studentSet2.addAll(studentSet1);

        System.out.println("Sorting based on Age");
        System.out.println(studentSet2);
    }

}
