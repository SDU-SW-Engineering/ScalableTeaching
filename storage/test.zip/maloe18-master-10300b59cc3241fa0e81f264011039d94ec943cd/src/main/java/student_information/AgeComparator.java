package student_information;

import java.util.Comparator;

public class AgeComparator implements Comparator<Student> {

    @Override
    public int compare(Student o1, Student o2) {
        int i = o1.getAge() - o2.getAge();
        if(i > 0){
            return 1;
        }else if(i < 0){
            return -1;
        }else
            return Double.compare(o1.getMarks(), o2.getMarks());
    }
}
